#include <stdio.h>


void main()
{
    printf("Hello World \n");
    printf("%ld",sizeof(long int));
}