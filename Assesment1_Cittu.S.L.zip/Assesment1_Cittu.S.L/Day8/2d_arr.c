/*
Program header 
1.Objective: Implementing 2d array
2.Revisions: Nil
3.Date & time of revision :10/10/24
4.Author Name: Cittu S L
*/
#include<stdio.h>

void main()
{
    int arr_2d[2][2]={{1,2},{3,4}};
}