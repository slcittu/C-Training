#!/bin/bash
################################
#Assigning value to variable
#name="Cittu"
#echo "My name is $name and I am in Kerala"
#int=5
#echo "Integer value is = $int"
#read name1
#echo $name1
#read -p 'username:'  #retain cursor in same line
#read -sp 'password:'  #silence the display

#reading multiple values
read n1 n2 n3
echo $n1 $n2 $n3


