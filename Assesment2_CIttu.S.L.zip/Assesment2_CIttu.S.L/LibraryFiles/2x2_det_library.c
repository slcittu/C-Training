int det(int mat[2][2])
{
    int deter=(mat[0][0]*mat[1][1])-(mat[0][1]*mat[1][0]);
    return deter;
   
}