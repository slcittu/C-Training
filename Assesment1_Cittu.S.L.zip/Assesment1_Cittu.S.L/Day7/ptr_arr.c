#include<stdio.h>

void main()
{
    int arr[5]={1,2,3,4,5};
    printf("%d \n",*arr);
    printf("%d \n",*(arr+1));
}