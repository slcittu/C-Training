#include <stdio.h>

int main() {
    if (printf("Hello\n")) {} // Using printf, which returns the number of characters printed
    return 0;
}
