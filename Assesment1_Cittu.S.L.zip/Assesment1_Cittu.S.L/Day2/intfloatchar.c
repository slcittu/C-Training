/*
Program Header
1.*/


#include <stdio.h>

void main()
{
    int a;
    float b;
    char c;

    // printf("Enter an integer value for A: \n");
    // scanf("%d",&a);
    // printf("Enter a float  value for B: \n");
    // scanf("%f",&b);
    printf("Enter an character value for C: \n");
    scanf(" %c",&c);
    a=c;
    printf("A= %d\n",a);
    printf("B= %f\n",b);
    printf("C= %c\n",c);

}