#!/bin/bash
############

echo HELLO WORLD
echo $BASH
echo $BASH_VERSION
echo $HOME
echo $PWD

